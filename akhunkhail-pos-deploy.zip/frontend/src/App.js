import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || "http://localhost:4000/api";

function App() {
  const [products, setProducts] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");

  useEffect(() => {
    axios.get(`${API}/products`).then(res => setProducts(res.data));
  }, []);

  const addProduct = async () => {
    await axios.post(`${API}/products`, { name, price, stock });
    const res = await axios.get(`${API}/products`);
    setProducts(res.data);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Akhunkhail Mega Mart POS</h1>
      <div className="mb-4">
        <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
        <input placeholder="Price" value={price} onChange={e => setPrice(e.target.value)} />
        <input placeholder="Stock" value={stock} onChange={e => setStock(e.target.value)} />
        <button onClick={addProduct}>Add Product</button>
      </div>
      <ul>
        {products.map((p, i) => (
          <li key={i}>{p.name} - ${p.price} (Stock: {p.stock})</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
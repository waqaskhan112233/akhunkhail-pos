const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let products = [
  { name: "Apple", price: 0.5, stock: 100 },
  { name: "Milk", price: 1.2, stock: 50 }
];

app.get('/api/products', (req, res) => {
  res.json(products);
});

app.post('/api/products', (req, res) => {
  const { name, price, stock } = req.body;
  products.push({ name, price, stock });
  res.json({ success: true });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Backend running on port ${port}`));
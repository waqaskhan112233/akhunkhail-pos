# Akhunkhail Mega Mart POS

## Deploy Frontend (Vercel)
1. Go to [Vercel](https://vercel.com) and login.
2. Create new project → Import from GitHub → select frontend folder.
3. Vercel will auto-deploy and give you a link like https://akhunkhail-pos.vercel.app

## Deploy Backend (Render)
1. Go to [Render](https://render.com) and login.
2. Create new Web Service → connect GitHub repo → select backend folder.
3. Set build command: `npm install`
4. Set start command: `node server.js`
5. Render will give you a link like https://akhunkhail-pos.onrender.com

## Connect Frontend to Backend
- In frontend, set environment variable: `REACT_APP_API_URL=https://akhunkhail-pos.onrender.com/api`
- Redeploy frontend to connect with backend.

Enjoy your POS system 🚀
